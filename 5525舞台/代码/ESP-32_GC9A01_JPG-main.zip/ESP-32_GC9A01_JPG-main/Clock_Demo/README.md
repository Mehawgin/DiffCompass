原作者：https://space.bilibili.com/16771062

所需库：  
ArduinoJson库  
FastLED库  
Time库  
TJpg_Decoder库  
TFT_eSPI库  

![img](https://github.com/Myzhazha/ESP-32_GC9A01_JPG/blob/main/img/4.jpg)  
