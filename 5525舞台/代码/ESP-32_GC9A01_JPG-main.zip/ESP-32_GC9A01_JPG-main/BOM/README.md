BOM表。
